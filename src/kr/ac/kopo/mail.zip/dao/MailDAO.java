package kr.ac.kopo.mail.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import kr.ac.kopo.mail.vo.MailVO;
import kr.ac.kopo.util.ConnectionFactory;

public class MailDAO {
	//전체메일
	public List<MailVO> selectAll(String user) throws Exception {
		
		List<MailVO> list = new ArrayList<>();
		
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT ROWNUM AS rw, WRITER, TITLE,REGDATE, RECEIVER, EMAIL_BODY");
		sql.append("  FROM (");
		sql.append("		SELECT WRITER, TITLE ,to_char(REG_DATE,'YYYY-MM-DD') AS REGDATE, RECEIVER, EMAIL_BODY");
		sql.append("		  FROM TBL_EMAIL");
		sql.append("         WHERE WRITER = ? OR RECEIVER = ? ");
		sql.append("         ORDER BY REG_DATE DESC");
		sql.append("       )");
		
		try(
			Connection conn = new ConnectionFactory().getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
		) {
			pstmt.setString(1, user);
			pstmt.setString(2, user);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) { //rs.next()의 값이 없어질때까지 출력
				String writer  = rs.getString("WRITER");
				String receiver = rs.getString("RECEIVER");
				String title   = rs.getString("TITLE");
				String emailBody = rs.getString("EMAIL_BODY");
				String regDate = rs.getString("REGDATE");
				int    no 	   = rs.getInt("rw");
				MailVO mail    = new MailVO(writer,receiver,title,emailBody,regDate,no);
				list.add(mail);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return list;
	}
	
	//수신메일
	public List<MailVO> selectrecive(String user) throws Exception {
		List<MailVO> list = new ArrayList<>();
		
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT ROWNUM AS rw, WRITER, TITLE,REGDATE, RECEIVER, EMAIL_BODY");
		sql.append("  FROM (");
		sql.append("		SELECT WRITER, TITLE ,to_char(REG_DATE,'YYYY-MM-DD') AS REGDATE, RECEIVER, EMAIL_BODY");
		sql.append("		  FROM TBL_EMAIL");
		sql.append("         WHERE RECEIVER = ? ");
		sql.append("         ORDER BY REG_DATE DESC");
		sql.append("       )");
		
		try(
				Connection conn = new ConnectionFactory().getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			) {
				pstmt.setString(1, user);
				ResultSet rs = pstmt.executeQuery();
				while(rs.next()) { //rs.next()의 값이 없어질때까지 출력
					String writer  = rs.getString("writer");
					String receiver = rs.getString("RECEIVER");
					String title   = rs.getString("title");
					String emailBody = rs.getString("email_body");
					String regDate = rs.getString("regdate");
					int    no 	   = rs.getInt("rw");
					
					MailVO mail    = new MailVO(writer,receiver,title,emailBody,regDate,no);
					list.add(mail);
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		
		return list;
	}
	
	
	//송신메일
	public List<MailVO> selectsend(String user) throws Exception {
		List<MailVO> list = new ArrayList<>();
		
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT ROWNUM AS rw, WRITER, TITLE,REGDATE, RECEIVER, EMAIL_BODY");
		sql.append("  FROM (");
		sql.append("		SELECT WRITER, TITLE ,to_char(REG_DATE,'YYYY-MM-DD') AS REGDATE, RECEIVER, EMAIL_BODY");
		sql.append("		  FROM TBL_EMAIL");
		sql.append("         WHERE WRITER = ? ");
		sql.append("         ORDER BY REG_DATE DESC");
		sql.append("       )");
		
		try(
				Connection conn = new ConnectionFactory().getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			) {
				pstmt.setString(1, user);
				ResultSet rs = pstmt.executeQuery();
				while(rs.next()) { //rs.next()의 값이 없어질때까지 출력
					int    no 	   = rs.getInt("rw");
					String writer  = rs.getString("writer");
					String receiver = rs.getString("RECEIVER");
					String title   = rs.getString("title");
					String emailBody = rs.getString("email_body");
					String regDate = rs.getString("regdate");
					MailVO mail    = new MailVO(writer,receiver,title,emailBody,regDate,no);
					list.add(mail);
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		
		return list;
	}
	
	public void mailWrite(MailVO mail) throws Exception{
		StringBuilder sql = new StringBuilder();
		sql.append("INSERT  INTO TBL_EMAIL(WRITER ,RECEIVER, TITLE, EMAIL_BODY, ID)");
		sql.append(" values(?, ?, ?, ?, ?) ");
		
		try(
			Connection conn = new ConnectionFactory().getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
		) {
			
			pstmt.setString(1, mail.getWriter());
			pstmt.setString(2, mail.getReceiver());
			pstmt.setString(3, mail.getTitle());
			pstmt.setString(4, mail.getEmailBody());
			pstmt.setString(5, mail.getWriter());	
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
