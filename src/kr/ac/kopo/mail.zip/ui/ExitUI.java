package kr.ac.kopo.mail.ui;

public class ExitUI extends BaseUI {

	@Override
	public void mlexecute() throws Exception {
		System.out.println("------------------------------------------");
		System.out.println("\n\t 프로그램을 종료합니다\n");
		System.out.println("------------------------------------------");
		System.exit(0);

	}

}
