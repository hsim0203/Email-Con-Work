package kr.ac.kopo.mail.ui;

public interface IMailUI {

	void mlexecute() throws Exception;
}
