package kr.ac.kopo.mail.ui;

import java.util.List;

import kr.ac.kopo.mail.vo.MailVO;

public class ReceiveMailUI extends BaseUI {

	@Override
	public void mlexecute() throws Exception {
		
		List<MailVO> list = mailService.receiveMail(user);
		System.out.println("--------------------------------------------------------");
		System.out.println("   		****** 수 신 메 일 함 *****   ");
		System.out.println("--------------------------------------------------------");
		System.out.println("번호\t송신자\t제목\t\t시간");
		System.out.println("--------------------------------------------------------");
		
		if(list == null || list.size() == 0) {
			System.out.println("게시글이 존재하지 않습니다");
		} else {
			for(MailVO mail : list) {
				System.out.println(mail.getNo() + "\t" + mail.getWriter() + "\t"+ mail.getTitle() + "\t\t"
						  + mail.getRegDate());
			}
		}

		System.out.println("--------------------------------------------------------");
			
	}	

	

}
